package com.example.moviedb

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //val genreJsonString =
            //resources.openRawResource(R.raw.genre).bufferedReader().use { it.readText() }
        //val genres = Genre()

        val nowPlayingJsonString =
            resources.openRawResource(R.raw.now_playing).bufferedReader().use { it.readText() }
        val nowPlaying = Movie.parseMovieJson(nowPlayingJsonString)

        val upcomingJsonString =
            resources.openRawResource(R.raw.upcoming).bufferedReader().use { it.readText() }
        val upcoming = Movie.parseMovieJson(upcomingJsonString)
        println(upcoming)
        println(nowPlaying)
    }
}
