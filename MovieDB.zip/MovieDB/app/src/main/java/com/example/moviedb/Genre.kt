package com.example.moviedb

class Genre (
){
}