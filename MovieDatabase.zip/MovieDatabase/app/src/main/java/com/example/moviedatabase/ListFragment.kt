package com.example.moviedatabase


import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.moviedb.Movie
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONObject

/**
 * A simple [Fragment] subclass.
 */
class ListFragment : Fragment(){
    lateinit var viewModel: MovieViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        viewModel = activity?.run { ViewModelProviders.of(this).get(MovieViewModel::class.java)
        }?: throw Exception("bad activity")
        return inflater.inflate(R.layout.fragment_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        (activity as AppCompatActivity).toolbar.title = ""

        val recyclerView = view.findViewById(R.id.upcoming_recyclerview) as RecyclerView
        val genreJsonString = resources.openRawResource(R.raw.genre).bufferedReader().use { it.readText() }
        val genre = GenreDecoder(genreJsonString).codes
//        val nowPlayingJsonString = resources.openRawResource(R.raw.now_playing).bufferedReader().use { it.readText() }
//        val now_playing = Movie.parseMovieJson(nowPlayingJsonString)
//        val upcomingJsonString = resources.openRawResource(R.raw.upcoming).bufferedReader().use { it.readText() }
//        val upcoming = Movie.parseMovieJson(upcomingJsonString)
        val linearLayoutManager = LinearLayoutManager(context)
        recyclerView.layoutManager = linearLayoutManager

        var cay = ArrayList<Movie>()
        val jsonString = resources.openRawResource(R.raw.now_playing).bufferedReader().use { it.readText() }
        val obj = JSONObject(jsonString)
        val userArray = obj.getJSONArray("results")
        for (i in 0 until userArray.length()){
            val userDetail = userArray.getJSONObject(i)
            val poster_path = userDetail.getString("poster_path")
            val backdrop_path = userDetail.getString("backdrop_path")
            val title = userDetail.getString("title")
            val vote_average = userDetail.getDouble("vote_average")
            val overview = userDetail.getString("overview")
            val release_date = userDetail.getString("release_date")
            var id = userDetail.getInt("id")
            val genres = "test"
            //val split_genres = genres.split(",")
            //var genreString = ""
            cay.add(Movie(0, false, poster_path, id, false, backdrop_path, "english", "test title",
                genres, title, vote_average, overview, release_date))
        }
        viewModel.movieList.value = cay
        val customAdapter = MovieAdapter(viewModel.movieList.value!!){
            movie: Movie -> RecyclerViewItemsSelected(movie)
        }
        recyclerView.adapter = customAdapter
    }
    fun RecyclerViewItemsSelected(movie: Movie){
        viewModel.movie.value = movie
        findNavController().navigate(R.id.action_listFragment_to_informationFragment)
    }

}
