package com.example.moviedatabase

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.navigation.findNavController
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(toolbar)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item?.itemId){
            R.id.action_now_playing->findNavController(R.id.nav_host_fragment)
                .navigate(R.id.action_global_listFragment)
        }
        when(item?.itemId){
            R.id.action_upcoming->findNavController(R.id.nav_host_fragment)
                .navigate(R.id.action_global_listFragment)
        }
        when(item?.itemId){
            R.id.action_saved_list->findNavController(R.id.nav_host_fragment)
                .navigate(R.id.action_global_savedFragment)
        }
        return true
    }
}
