package com.example.moviedatabase

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.example.moviedb.Movie

class MovieViewModel(application: Application): AndroidViewModel(application) {

    var movie = MutableLiveData<Movie>()
    var movieList = MutableLiveData<ArrayList<Movie>>()

    init {
        if (movie.value == null)
            //review.value = Movie()
        movieList.value = ArrayList()
    }

    fun addMovie(movie: Movie){
        movieList.value?.add(movie)
    }

    fun saveReview(text: String, stars: Float){
        movie.value?.title = text
        //movie.value?.stars = stars
    }
    fun removeReview(index: Int) {
        movieList.value?.removeAt(index)
    }

}