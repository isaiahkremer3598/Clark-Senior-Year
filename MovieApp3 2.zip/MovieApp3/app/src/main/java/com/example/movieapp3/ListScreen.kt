package com.example.movieapp3
//          determining if the upcoming or now playing should be displayed
//        var textView = view.findViewById<TextView>(R.id.whichScreen)
//        var incomingScreen = arguments?.getString("whichScreen")
//        if(incomingScreen == "upcomingScreen"){
//            textView.text = incomingScreen
//        }
//        if(incomingScreen == "nowplayingScreen"){
//            textView.text = incomingScreen
//        }

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ListAdapter
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.moviedatabase.GenreDecoder
import com.example.moviedatabase.MovieAdapter
import com.example.moviedatabase.MovieViewModel
import com.example.moviedb.Movie
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.fragment_list_screen.*
import org.json.JSONObject

/**
 * A simple [Fragment] subclass.
 */
class ListScreen : Fragment() {
    lateinit var viewModel: MovieViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        viewModel = activity?.run { ViewModelProviders.of(this).get(MovieViewModel::class.java)
        }?: throw Exception("bad activity")
        return inflater.inflate(R.layout.fragment_list_screen, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        (activity as AppCompatActivity).toolbar.title = ""

        val recyclerView = view.findViewById(R.id.list_recyclerview) as RecyclerView
        val genreJsonString = resources.openRawResource(R.raw.genre).bufferedReader().use { it.readText() }
        val genre = GenreDecoder(genreJsonString).codes
//        val nowPlayingJsonString = resources.openRawResource(R.raw.now_playing).bufferedReader().use { it.readText() }
//        val now_playing = Movie.parseMovieJson(nowPlayingJsonString)
//        val upcomingJsonString = resources.openRawResource(R.raw.upcoming).bufferedReader().use { it.readText() }
//        val upcoming = Movie.parseMovieJson(upcomingJsonString)
        val linearLayoutManager = LinearLayoutManager(context)
        recyclerView.layoutManager = linearLayoutManager

        var incomingScreen = arguments?.getString("whichScreen")
        if(incomingScreen == "upcomingScreen"){
            var cay = ArrayList<Movie>()
            val jsonString = resources.openRawResource(R.raw.upcoming).bufferedReader().use { it.readText() }
            val obj = JSONObject(jsonString)
            val userArray = obj.getJSONArray("results")
            for (i in 0 until userArray.length()){
                val userDetail = userArray.getJSONObject(i)
                val poster_path = userDetail.getString("poster_path")
                val backdrop_path = userDetail.getString("backdrop_path")
                val title = userDetail.getString("title")
                val vote_average = userDetail.getDouble("vote_average")
                val overview = userDetail.getString("overview")
                val release_date = userDetail.getString("release_date")
                var id = userDetail.getInt("id")
                val genres = userDetail.getString("genre_ids")
                var review = ""
                var star = 0.0f
                val split_genres = genres.split(",")
                var genreString = ""
                for (i in 0 until split_genres.size){
                    val genrenumber = split_genres[i].
                        replace("[", "")
                        .replace("]", "")
                        .toInt()
                    if (i == split_genres.size - 1){
                        genreString += genre.get(genrenumber)
                    }else{
                        genreString += genre.get(genrenumber) + ", "
                    }
                }
                val genreStr = genreString
                cay.add(
                    Movie(
                        0, false, poster_path, id, false, backdrop_path, "english", "test title",
                        genreStr, title, vote_average, overview, release_date, review, star
                    )
                )
            }
            viewModel.movieList.value = cay
            val customAdapter = MovieAdapter(viewModel.movieList.value!!){
                    movie: Movie -> RecyclerViewItemsSelected(movie)
            }
            recyclerView.adapter = customAdapter
        }
        else{
            var cay = ArrayList<Movie>()
            val jsonString = resources.openRawResource(R.raw.now_playing).bufferedReader().use { it.readText() }
            val obj = JSONObject(jsonString)
            val userArray = obj.getJSONArray("results")
            for (i in 0 until userArray.length()){
                val userDetail = userArray.getJSONObject(i)
                val poster_path = userDetail.getString("poster_path")
                val backdrop_path = userDetail.getString("backdrop_path")
                val title = userDetail.getString("title")
                val vote_average = userDetail.getDouble("vote_average")
                val overview = userDetail.getString("overview")
                val release_date = userDetail.getString("release_date")
                var id = userDetail.getInt("id")
                val genres = userDetail.getString("genre_ids")
                var review = ""
                var star = 0.0f
                val split_genres = genres.split(",")
                var genreString = ""
                for (i in 0 until split_genres.size){
                    val genrenumber = split_genres[i].
                        replace("[", "")
                        .replace("]", "")
                        .toInt()
                    if (i == split_genres.size - 1){
                        genreString += genre.get(genrenumber)
                    }else{
                        genreString += genre.get(genrenumber) + ", "
                    }
                }
                val genreStr = genreString
                cay.add(
                    Movie(
                        0, false, poster_path, id, false, backdrop_path, "english", "test title",
                        genreStr, title, vote_average, overview, release_date, review, star
                    )
                )
            }
            viewModel.movieList.value = cay
            val customAdapter = MovieAdapter(viewModel.movieList.value!!){
                    movie: Movie -> RecyclerViewItemsSelected(movie)
            }
            recyclerView.adapter = customAdapter
        }


    }
    fun RecyclerViewItemsSelected(movie: Movie){
        viewModel.movie.value = movie
        findNavController().navigate(R.id.action_listScreen_to_detailScreen)
    }

}