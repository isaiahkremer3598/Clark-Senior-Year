package com.example.moviedb
import org.json.JSONArray
import org.json.JSONObject

class Movie (
    //var popularity: Double,
    var vote_count: Int,
    var video: Boolean,
    var poster_path: String,
    var id: Int,
    var adult: Boolean,
    var backdrop_path: String,
    var original_language: String,
    var original_title: String,
    var genre_ids: String,
    var title: String,
    var vote_average: Double,
    var overview: String,
    var release_date: String,
    var review : String,
    var stars : Float

){
    companion object {

        //Parse the json file to a Stock object
        fun parseMovieJson(json: String): Array<Movie> {
            val data = JSONObject(json)
            val dataArray = Array(data.length()) { Movie( 0, false, "", 0, false, "", "",
                "", "", "", 0.0, "", "", "", 0.0f) }
            val movieArray = data.getJSONArray("results")

            for (i in 0 until dataArray.size) {
                val movieObject = movieArray.getJSONObject(i)
                //dataArray[i].popularity = movieObject.getDouble("popularity")
                dataArray[i].vote_count = movieObject.getInt("vote_count")
                dataArray[i].video = movieObject.getBoolean("video")
                dataArray[i].poster_path = movieObject.getString("poster_path")
                dataArray[i].id = movieObject.getInt("id")
                dataArray[i].adult = movieObject.getBoolean("adult")
                dataArray[i].backdrop_path = movieObject.getString("backdrop_path")
                dataArray[i].original_language = movieObject.getString("original_language")
                dataArray[i].original_title = movieObject.getString("original_title")
                dataArray[i].genre_ids = ""
                dataArray[i].title = movieObject.getString("title")
                dataArray[i].vote_average = movieObject.getDouble("vote_average")
                dataArray[i].overview = movieObject.getString("overview")
                dataArray[i].release_date = movieObject.getString("release_date")
            }
            return dataArray
        }
    }

}
