package com.example.movieapp3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.StrictMode
import android.view.Menu
import android.view.MenuItem
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONArray

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        if (android.os.Build.VERSION.SDK_INT > 9) {
            val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
            StrictMode.setThreadPolicy(policy)
        }
//        val nowplaying = resources.openRawResource(R.raw.now_playing).bufferedReader().use { it.readText() }
//        val string = Movie.parseMovieJson(nowplaying)


//      need to change manifest file in order for this to work
        setSupportActionBar(findViewById(R.id.toolbar))


        val navController=findNavController(R.id.nav_host_fragment)
        toolbar.setupWithNavController(navController)
    }

//    class Movie(
//        var popularity: Double,
//        var vote_count: Int,
//        var video: Boolean,
//        var poster_path: String,
//        var id: Double,
//        var adult: Boolean,
//        var backdrop_path: String,
//        var original_language: String,
//        var original_title: String,
//        var genre_ids: ArrayList<Int>,
//        var title: String,
//        var vote_average: Double,
//        var overview: String
//    ){
//
//        companion object {
//
//            //Parse the json file to a Stock object
//            fun parseMovieJson(json: String): Array<Movie> {
//                val data = JSONArray(json)
//                val newMovieList = Array(data.length()) { Movie(0.0, 0, false, "", 0.0, false,
//                    "", "", "", ArrayList(),"",0.0, "") }
//                for (i in 0 until newMovieList.size) {
//                    val stockObject = data.getJSONObject(i)
//                    newMovieList[i].popularity = stockObject.getDouble("popularity")
//                    newMovieList[i].vote_count = stockObject.getInt("vote_count")
//                    newMovieList[i].video = stockObject.getBoolean("Sector")
//                    newMovieList[i].poster_path = stockObject.getString("poster_path")
//                    newMovieList[i].id = stockObject.getDouble("id")
//                    newMovieList[i].adult = stockObject.getBoolean("adult")
//                    newMovieList[i].backdrop_path = stockObject.getString("backdrop_path")
//                    newMovieList[i].original_language = stockObject.getString("original_language")
//                    newMovieList[i].original_title = stockObject.getString("original_title")
//                    val genres = stockObject.getJSONArray("genre_ids")
//                    for (g in 0 until genres.length()){
//                        newMovieList[i].genre_ids.add(genres[g].toString().toInt())
//                    }
//
//                    newMovieList[i].title = stockObject.getString("title")
//                    newMovieList[i].vote_average = stockObject.getDouble("vote_average")
//                    newMovieList[i].overview = stockObject.getString("overview")
//
//                }
//                return newMovieList
//
//            }
//        }
//    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        if(item?.itemId == R.id.action_upcoming){
            val bundle = Bundle()
            bundle.putString("whichScreen", "upcomingScreen")
            findNavController(R.id.nav_host_fragment)
                .navigate(R.id.action_global_listScreen, bundle)
        }

        if(item?.itemId == R.id.action_nowplaying){
            val bundle = Bundle()
            bundle.putString("whichScreen", "nowplayingScreen")
            findNavController(R.id.nav_host_fragment)
                .navigate(R.id.action_global_listScreen, bundle)
        }

        when(item?.itemId){
            R.id.action_savedlist->findNavController(R.id.nav_host_fragment)
                .navigate(R.id.action_global_savedScreen)
        }

        return true
    }
}
