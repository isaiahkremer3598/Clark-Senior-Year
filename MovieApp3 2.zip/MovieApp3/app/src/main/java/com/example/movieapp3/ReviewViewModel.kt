package com.example.movieapp3

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData

class ReviewViewModel(application: Application): AndroidViewModel(application) {

    var review = MutableLiveData<Review>()
    var movieList = MutableLiveData<ArrayList<Review>>()

    init {
        if (review.value == null)
            review.value = Review()
        movieList.value = ArrayList()
    }

    fun addMovie(review: Review){
        movieList.value?.add(review)
    }

    fun saveReview(text: String, stars: Float){
        review.value?.text = text
        review.value?.stars = stars
    }
    fun removeReview(index: Int) {
        movieList.value?.removeAt(index)
    }

}