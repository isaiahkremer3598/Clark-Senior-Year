package com.example.moviedatabase

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.movieapp3.R
import com.example.moviedb.Movie

class MovieAdapter (
    val movieData: ArrayList<Movie>,
    val clickListener: (Movie)->Unit ) : RecyclerView.Adapter<MovieAdapter.RecyclerViewHolder>()
{
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.now_playing_data, parent, false)
        return RecyclerViewHolder(v)
    }

    override fun onBindViewHolder(holder: RecyclerViewHolder, position: Int) {
        holder.movieName.text = movieData[position].title
        holder.movieGenre.text = movieData[position].genre_ids
        PosterLoader.getInstance().loadURL(movieData[position].poster_path, holder.moviePoster)
        holder.bind(movieData[position], clickListener)

    }

    override fun getItemCount(): Int {
        return movieData.size
    }

    inner class RecyclerViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        internal var movieName: TextView = itemView.findViewById(R.id.now_playing_title) as TextView
        internal var movieGenre: TextView = itemView.findViewById(R.id.now_playing_genre) as TextView
        internal var moviePoster: ImageView = itemView.findViewById(R.id.now_playing_poster) as ImageView
        fun bind(movie: Movie, clickListener: (Movie) -> Unit){
            itemView.setOnClickListener {
                clickListener(movie)
            }
        }
    }
}