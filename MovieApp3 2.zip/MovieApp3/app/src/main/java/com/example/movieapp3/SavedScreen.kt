package com.example.movieapp3


import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.RatingBar
import android.widget.TextView
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.Navigation
import androidx.navigation.Navigation.findNavController
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.fragment_saved_screen.*
import kotlinx.android.synthetic.main.saved_item.view.*

/**
 * A simple [Fragment] subclass.
 */
class SavedScreen : Fragment(), DetailScreen.OnFragmentInteractionListener {


    lateinit var viewModel: ReviewViewModel
    var selectedReviewText = ""
    var selectedReviewRating = 0.0f
    var selectedReview = Review()

    override fun getSavedRestaurant(): Review {
        return selectedReview
    }



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        viewModel = activity?.run {
            ViewModelProviders.of(this).get(ReviewViewModel::class.java)
        } ?: throw Exception("bad activity")
        var view = inflater.inflate(R.layout.fragment_saved_screen, container, false)


        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
//        val coffeeList = listener.getCart()
        viewManager = LinearLayoutManager(context)
        viewAdapter = RecyclerViewAdapter(ArrayList<Review>())
        saved_recyclerview.apply {
            layoutManager = viewManager
            adapter = viewAdapter
        }



        viewModel.movieList.observe(this, Observer {
            viewAdapter.list = it
            viewAdapter.notifyDataSetChanged()
        })

        ItemTouchHelper(SwipeHelper()).attachToRecyclerView(
            saved_recyclerview
        )


    }

    inner class SwipeHelper(): ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT){
        override fun onMove(
            recyclerView: RecyclerView,
            viewHolder: RecyclerView.ViewHolder,
            target: RecyclerView.ViewHolder
        ): Boolean {
            return false
        }

        override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
            viewModel.removeReview(viewHolder.adapterPosition)
            viewAdapter.notifyDataSetChanged()
//            listener.updateCart()
        }

    }

    lateinit var viewAdapter: RecyclerViewAdapter
    lateinit var viewManager: RecyclerView.LayoutManager

    class RecyclerViewAdapter(var list: ArrayList<Review>) :
        RecyclerView.Adapter<RecyclerViewAdapter.RecyclerViewHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerViewHolder {
            var viewItem =
                LayoutInflater.from(parent.context).inflate(R.layout.saved_item, parent, false)
            return RecyclerViewHolder(viewItem)
        }

        override fun getItemCount(): Int {
            return list.size
        }

        override fun onBindViewHolder(holder: RecyclerViewHolder, position: Int) {
            return holder.bind(list[position])
        }

        class RecyclerViewHolder(val viewItem: View) : RecyclerView.ViewHolder(viewItem) {
            init {
                var linearLayout = viewItem.findViewById<LinearLayout>(R.id.savedScreenItem)
                linearLayout.setOnClickListener{
                    SavedScreen().selectedReviewText = linearLayout.savedTextView.text.toString()
                    SavedScreen().selectedReviewRating = linearLayout.savedRatingBar.rating
                    SavedScreen().selectedReview.text = SavedScreen().selectedReviewText
                    SavedScreen().selectedReview.stars = SavedScreen().selectedReviewRating
                    SavedScreen().getSavedRestaurant()
                    var bundle = Bundle()
                    bundle.putString("whichScreen", "savedScreen")
                    Navigation.findNavController(viewItem).navigate(R.id.action_savedScreen_to_detailScreen, bundle)
                }
            }
            fun bind(review: Review) {
                viewItem.run {
                    findViewById<TextView>(R.id.savedTextView).text = review.text
                    findViewById<RatingBar>(R.id.savedRatingBar).rating = review.stars
                }
            }
        }
    }





}
