package com.example.movieapp3


import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.fragment.findNavController
import kotlinx.android.synthetic.main.fragment_detail_screen.*
import kotlinx.android.synthetic.main.fragment_review_screen.*

/**
 * A simple [Fragment] subclass.
 */
class ReviewScreen : Fragment() {

    lateinit var viewModel: ReviewViewModel
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        viewModel = activity?.run {
            ViewModelProviders.of(this).get(ReviewViewModel::class.java)
        } ?: throw Exception("bad activity")
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_review_screen, container, false)
    }

    fun saveInfo(){
        viewModel.saveReview(editTextReview.text.toString(), reviewRatinBar.rating)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        viewModel.review.observe(this, Observer {
            editTextReview.setText(it.text)
            reviewRatinBar.rating = it.stars
        })

        saveButtonReview.setOnClickListener {
            saveInfo()
            viewModel.addMovie(createReview())
            findNavController().navigate(R.id.action_reviewScreen_to_detailScreen)
        }
        cancelButtonReview.setOnClickListener {
            val bundle = Bundle()
            bundle.putString("whichButton", "cancelButton")
//            bundle.putString("clickedRestaurant", restaurantName.text.toString())
            findNavController().navigate(R.id.action_reviewScreen_to_detailScreen, bundle)
        }


    }

    fun createReview(): Review{
        var review = Review()
        var text = editTextReview.text.toString()
        var stars = reviewRatinBar.rating
        review.text = text
        review.stars = stars
        return review
    }


}
