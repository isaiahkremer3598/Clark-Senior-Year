package com.example.movieapp3


import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isInvisible
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.fragment.findNavController
import kotlinx.android.synthetic.main.fragment_detail_screen.*
import kotlinx.android.synthetic.main.fragment_list_screen.*
import kotlinx.android.synthetic.main.fragment_review_screen.*

/**
 * A simple [Fragment] subclass.
 */
class DetailScreen : Fragment() {

    var review = Review()

    var selectedScreen: String? = ""
    var cancelButton: String? = ""
    lateinit var viewModel: ReviewViewModel
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {


        selectedScreen = arguments?.getString("whichScreen")
        cancelButton = arguments?.getString("whichButton")
//        review = listener.getSavedRestaurant()

        viewModel = activity?.run {
            ViewModelProviders.of(this).get(ReviewViewModel::class.java)
        } ?: throw Exception("bad activity")
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_detail_screen, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        if(cancelButton == "cancelButton"){
            reviewTextView.visibility = View.INVISIBLE
            detailRatingBar.visibility = View.INVISIBLE

        }

        if(selectedScreen == "savedScreen"){
//            review = listener.getSavedRestaurant()
            reviewTextView.text = review.text
            detailRatingBar.rating = review.stars
        }else {


            viewModel.review.observe(this, Observer {
                reviewTextView.text = it.text
                detailRatingBar.rating = it.stars
            })
        }
        likeButton.setOnClickListener {
            findNavController().navigate(R.id.action_detailScreen_to_reviewScreen)
        }
        detailEditButton.setOnClickListener {
            findNavController().navigate(R.id.action_detailScreen_to_reviewScreen)
        }


    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is OnFragmentInteractionListener) {
            listener = context
        }
    }

    lateinit var listener: OnFragmentInteractionListener

    interface OnFragmentInteractionListener {
        fun getSavedRestaurant(): Review
    }


}
