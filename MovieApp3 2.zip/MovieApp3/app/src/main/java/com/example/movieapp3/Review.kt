package com.example.movieapp3

class Review {

    var text = "some review"
    var stars = 0.0f
}